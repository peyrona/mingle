#!/usr/bin/env bash

# Exit on error, undefined variables, and pipe failures
set -euo pipefail
IFS=$'\n\t'

# Script constants
readonly WORK_PATH="/home/balata"
readonly DEFAULT_PASSWORD="balata0801"
readonly REQUIRED_PACKAGES=(htop watchdog)
readonly CONFIG_BACKUP_DIR="/opt/balata/backups/$(date +%Y%m%d_%H%M%S)"
readonly LOG_FILE="/var/log/balata-installer.log"
readonly DNS_SERVERS="1.1.1.1 9.9.9.9"

# Colors for output
readonly RED='\033[0;31m'
readonly GREEN='\033[0;32m'
readonly YELLOW='\033[1;33m'
readonly NC='\033[0m' # No Color

# Logging function
log()
{
    local level="$1"
    shift
    local message="$*"
    local timestamp
    timestamp="$(date '+%Y-%m-%d %H:%M:%S')"
    echo -e "${timestamp} [${level}] ${message}" | tee -a "$LOG_FILE"
}

# Error handling
error()
{
    log "ERROR" "${RED}$*${NC}"
    exit 1
}

# Check for root privileges
check_root()
{
    if [[ $EUID -ne 0 ]]; then
        error "This script must be run as root. Use: 'sudo $0'"
    fi
}

# Check system architecture
check_architecture()
{
    local arch=$(uname -m)

    if [[ ! $arch =~ ^(arm|aarch).* ]]; then
        error "This script requires an ARM-based system. Detected architecture: $arch"
    fi
}

# Create required directories
create_directories()
{
    mkdir -p "$WORK_PATH" "$CONFIG_BACKUP_DIR"
    chmod 750 "$WORK_PATH" "$CONFIG_BACKUP_DIR"
    log "INFO" "Required directories were created..."
}

# Backup configuration file
backup_config()
{
    local file="$1"

    if [[ -f "$file" ]]; then
        log "INFO" "Backing up $file..."
        cp -p "$file" "${CONFIG_BACKUP_DIR}/$(basename "$file").backup"
    fi
}

# Configure static IP
configure_network()
{
    log "INFO" "Select the machine number to configure:"

    declare -A IP_CONFIG=(       # The -A specifies it's an associative array: allows key-value pairs
        ["6"]="E1"
        ["7"]="A1"
        ["8"]="E2"
        ["9"]="A2"
    )

    for key in "${!IP_CONFIG[@]}"; do
        log "$key -> ${IP_CONFIG[$key]%%:*}"
    done

    local ip_choice

    while true; do
        read -r -p "Enter selection: " ip_choice
        if [[ -n "${IP_CONFIG[$ip_choice]:-}" ]]; then
            break
        fi
        log "WARN" "Invalid option. Please try again."
    done

    local fixed_ip="192.168.$ip_choice.9"
    local router_ip="192.168.$ip_choice.1"

    # Backup and configure dhcpcd.conf
    backup_config "/etc/dhcpcd.conf"

    cat << EOF >> /etc/dhcpcd.conf

# Static IP configuration for Balata
interface eth0
static ip_address=$fixed_ip/24
static routers=$router_ip
static domain_name_servers=$DNS_SERVERS
EOF

    systemctl restart dhcpcd || error "Failed to restart dhcpcd service"
    log "INFO" "Network configured with IP: $fixed_ip"
    log "INFO" "Network configured with Router: $router_ip"
}

check_internet()
{
    # Test multiple reliable hosts
    local test_hosts=("8.8.8.8" "1.1.1.1" "google.com")
    local connected=false

    log "Checking internet connection..."

    # First try ping
    for host in "${test_hosts[@]}"; do
        if ping -c 1 -W 2 "$host" &>/dev/null; then
            connected=true
            log "Internet connection verified via ping to $host"
            return 0
        fi
    done

    # If ping fails, try wget as alternative
    if wget -q --spider https://google.com; then
        connected=true
        echo "Internet connection verified via wget"
        return 0
    fi

    # If all checks fail
    if [ "$connected" = false ]; then
        error "No internet connection available"
    fi
}

# System upgrade
upgrade_system()
{
    if ! command -v apt-get >/dev/null; then
        error "Package manager 'apt-get' not found. This script requires a Debian-based system."
    fi

    log "INFO" "Updating system packages..."
    apt-get update || error "Failed to update package lists"

    log "INFO" "Installing required packages..."
    apt-get install -y "${REQUIRED_PACKAGES[@]}" || error "Failed to install required packages"

    log "INFO" "Upgrading system..."
    apt-get upgrade -y || error "Failed to upgrade system"
}

# Configure locale
configure_locale()
{
    log "INFO" "Configuring system locales..."
    local required_locales=("es_ES.UTF-8")

    for locale in "${required_locales[@]}"; do
        if ! locale -a | grep -q "${locale%.*}"; then
            log "INFO" "Generating locale $locale..."
            locale-gen "$locale" || error "Failed to generate locale $locale"
        fi
    done
}

# Configure timezone
configure_timezone()
{
    log "INFO" "Configuring timezone..."
    timedatectl set-ntp true
    timedatectl set-timezone Europe/Madrid || error "Failed to set timezone"

    if ! grep -q "^NTP=pool.ntp.org" /etc/systemd/timesyncd.conf; then
        backup_config "/etc/systemd/timesyncd.conf"
        sed -i '/\[Time\]/a NTP=pool.ntp.org' /etc/systemd/timesyncd.conf
    fi

    systemctl restart systemd-timesyncd || error "Failed to restart timesyncd service"
}

# Enable SSH Server
activate_ssh()
{
    log "Activating SSH server..."

    # Check if ssh service exists
    if ! systemctl list-unit-files ssh.service &>/dev/null && ! systemctl list-unit-files sshd.service &>/dev/null; then
        log "Installing SSH server..."
        apt-get update
        apt-get install -y openssh-server
    fi

    # Different distros might use ssh.service or sshd.service
    local SSH_SERVICE="ssh.service"

    if systemctl list-unit-files sshd.service &>/dev/null; then
        SSH_SERVICE="sshd.service"
    fi

    systemctl enable "$SSH_SERVICE"    # Enable SSH on startup

    # Start SSH service
    if systemctl start "$SSH_SERVICE"; then
        if systemctl is-active --quiet "$SSH_SERVICE"; then
            log "SSH server is now active and enabled on startup"
            return 0
        else
            log "Error: Failed to start SSH server"
            return 1
        fi
    else
        log "Error: Failed to start SSH service"
        return 1
    fi
}

# Configure watchdog
configure_watchdog()
{
    log "INFO" "Configuring hardware watchdog..."

    # Install watchdog if not present
    if ! command -v watchdog >/dev/null; then
        apt-get install -y watchdog || error "Failed to install watchdog"
    fi

    # Configure kernel module
    if ! grep -q "^bcm2708_wdog" /etc/modules; then
        echo "bcm2708_wdog" >> /etc/modules
    fi

    modprobe bcm2708_wdog || error "Failed to load watchdog kernel module"

    # Configure watchdog service
    backup_config "/etc/watchdog.conf"
    cat << EOF > /etc/watchdog.conf
watchdog-device = /dev/watchdog
watchdog-timeout = 30
max-load-1 = 36
min-memory = 5
realtime = yes
priority = 1
EOF

    systemctl enable watchdog
    systemctl start watchdog

    if ! systemctl is-active --quiet watchdog; then
        error "Watchdog service failed to start"
    fi
}

# Creates 'balata' user (if not exists) with root privileges
create_admin_user()
{
    local username="balata"
    local password="balata0801"

    # Check if user exists
    if id "$username" &>/dev/null; then
        log "User $username already exists"
    else
        useradd -m "$username"                   # Create user with home directory

        log "$username:$password" | chpasswd     # Set password

        usermod -aG sudo "$username"             # Add user to sudo group

        log "$username ALL=(ALL:ALL) ALL" | sudo tee "/etc/sudoers.d/$username"      # Create sudoers file for the user

        chmod 440 "/etc/sudoers.d/$username"     # Set proper permissions for sudoers file

        log "User $username created successfully with root privileges"
    fi
}

# Deletes a user if exists (used to delete "pi")
delete_user()
{
    local username="$1"

    # Check if user exists
    if id "$username" &>/dev/null; then
        log "User $username found. Proceeding with deletion..."

        pkill -u "$username"    # Kill any processes owned by the user

        userdel "$username"     # Delete user

        # Check if home directory exists and delete it
        if [ -d "/home/$username" ]; then
            rm -rf "/home/$username"
            log "Removed /home/$username directory..."
        fi

        log "User $username and associated data successfully removed"
    else
        log "User $username does not exist: no need to delete it"
        return 1
    fi
}

# Main installation process ----------------------------------------------------------
main()
{
    check_root
    check_architecture
    create_directories

    log "INFO" "Starting Balata installation..."    # Can not log until dirs are created

    # Interactive confirmations
    read -r -p "Configure network? [y/N] " response
    [[ ${response,,} =~ ^(y|yes)$ ]] && configure_network

    check_internet

    read -r -p "Upgrade system? [y/N] " response
    [[ ${response,,} =~ ^(y|yes)$ ]] && upgrade_system

    read -r -p "Activate SSH server? [y/N] " response
    [[ ${response,,} =~ ^(y|yes)$ ]] && activate_ssh

    read -r -p "Configure locales? [y/N] " response
    [[ ${response,,} =~ ^(y|yes)$ ]] && configure_locale

    configure_timezone
    configure_watchdog

    chown -R balata:balata "$WORK_PATH"

    if create_admin_user; then
        delete_user pi
    fi

    log "INFO" "Installation completed"

    read -r -p "Reboot system? [y/N] " response
    if [[ ${response,,} =~ ^(y|yes)$ ]]; then
        log "INFO" "Rebooting system..."
        shutdown -r now
    fi
}

main "$@"