
"use strict";

if( typeof clima === "undefined" )
{
var clima =
{
    jMsg      : {},    // Last received JSON message about the state of the Emura
    bInited   : false,
    aContacts : [],    // Windows contact (open/close)
    oLimits   : { 'Cool': { min:19, max:28 } , 'Heat': { min:17, max:24 } },   // jMsg.Mode: 'Cool', 'Heat', 'Dry' or 'Auto'

    init : function()
    {
        if( clima.bInited )
            return; //throw "Calling twice to clima:init()";

        this.bInited = true;

        gum_ws.addListener( oExEnAddr, 'contact_*',
                            (action, payload) => clima.onWindoStateChanged( payload.value.data ) );

        gum_ws.addListener( oExEnAddr, 'clima_sensor',
                            (action, payload) =>
                            {
                                $('#temperature_inside' ).text( clima.formatTemperature( payload.value.data.t_inside  ) + (clima.isFahrenheit() ? 'F' : 'C') );
                                $('#temperature_outside').text( clima.formatTemperature( payload.value.data.t_outside ) + (clima.isFahrenheit() ? 'F' : 'C') );
                            } );

        gum_ws.addListener( oExEnAddr, 'clima_ctrl',
                            (action, payload) => clima._update_( payload.value.data ) );
    },

    refresh : function()
    {
        gum_ws.requestValue( oExEnAddr, 'clima_sensor' );
        gum_ws.requestValue( oExEnAddr, 'clima_ctrl'   );
    },

    onPowerClicked : function()
    {
        if( this.aContacts.length > 0 )
            return;

        if( this.jMsg.power )
        {
            gum_ws.requestChange( oExEnAddr, 'clima_ctrl', { power: false } );
            blockGUI( (isDevEnv ? 1 : 20) );
        }
        else    // Está en OFF
        {
            gum_ws.requestChange( oExEnAddr, 'clima_ctrl', { power: true } );
            blockGUI( (isDevEnv ? 1 : 17) );
        }
    },

    onModeClicked : function( source )
    {
        if( ! this.jMsg.power )
            return;

        let mode = null;

        switch( source.id )
        {
            case 'modeAuto': mode = 'Auto'; break;
            case 'modeCool': mode = 'Cool'; break;
            case 'modeDry' : mode = 'Dry';  break;
            case 'modeHeat': mode = 'Heat'; break;
            case 'modeFan' : mode = 'Fan';  break;
            default        : throw 'Error '+ source.id;
        }

        if( ! p_base.areEquals( this.jMsg.mode.toLowercase(), mode ) )
        {
            gum_ws.requestChange( oExEnAddr, 'clima_ctrl', { mode: mode } );
            blockGUI( 1 );
        }
    },

    onFanclicked : function( source )
    {
        if( ! this.jMsg.power )
            return;

        let level = null;

        switch( source.id )
        {
            case 'fan_7': level = 'Maximum'; break;
            case 'fan_6': level = 'High';    break;
            case 'fan_5': level = 'Medium';  break;
            case 'fan_4': level = 'Low';     break;
            case 'fan_3': level = 'Minimum'; break;
            default     : throw 'Error '+ source.id;
        }

        if( this.jMsg.fan !== level )
        {
            gum_ws.requestChange( oExEnAddr, 'clima_ctrl', { fan: level } );
            blockGUI( 1 );
        }
    },

    onIncrTempe : function( incr )       // incr puede ser positivo (.5) o negativo (-.5)
    {
        if( ! this.jMsg.power )
            return;

        if( (this.jMsg.mode !== 'Cool') && (this.jMsg.mode !== 'Heat') )
            return;
                                                                // 21ºC is the default
        let value = (this.getShownTemperatureInCelsius() == null ? 21 : this.getShownTemperatureInCelsius()) + incr;
        let min   = this.oLimits[this.jMsg.mode].min;
        let max   = this.oLimits[this.jMsg.mode].max;

        value = value < min ? min : value;
        value = value > max ? max : value;

        gum_ws.requestChange( oExEnAddr, 'clima_ctrl', { t_target: value } );

        blockGUI( .5 );
    },

    /**
     * Se han abierto o cerrado ventanas en la habitación.
     */
    onWindoStateChanged : function( sDevName, isClosed )
    {
        if( isClosed )     // Window had been closed
        {
            if( this.aContacts.includes( sDevName ) )
                this.aContacts.splice( this.aContacts.indexOf( sDevName ), 1 );   // Removes from array
        }
        else
        {
            if( ! this.aContacts.includes( sDevName ) )
                this.aContacts.push( sDevName );                                  // Adds to array
        }

        if( this.aContacts.length > 0 )  $("#_info_box_").show();
        else                             $("#_info_box_").hide();

        if( this.aContacts.length > 0 && this.jMsg.power )
            gum_ws.requestChange( oExEnAddr, 'clima_ctrl', { power: false } );
    },

    onChangeUnit : function()
    {
        let value = $("#_target_tempe_").text();

        if( p_base.isEmpty( value ) )    // Si está vacía la temperatura de consigna
            return;

        value = Number.parseFloat( value );

        if( ! Number.isNaN( value ) )
        {
            if( this.isFahrenheit() )   // Pasamos a Celsius
            {
                value = this.toCelsius( value );
                $("#_tempe_unit_").html( "C" );
            }
            else                        // Pasamos a Fahrenheit
            {
                // value = this.toFahrenheit( value ); --> This is done at formatTemperature()
                $("#_tempe_unit_").html( "F" );
            }

            $("#_target_tempe_").text( this.formatTemperature( value ) );
        }
    },

    onHelp : function()
    {
        $("#ClimaHelpDialog").dialog();
    },

    //-------------------------------------------------------------------------------------------//
    // PRIVATE METHODS

    // A message has arrived from the Server informing 'clima_ctrl' has changed its status (msg arrives with all values).
    // Because the listener that calls here filters messages, messages that arrive here are about 'clima_ctrl'.

    _update_ : function( jMsg )
    {
        this.jMsg = { ...this.jMsg, ...jMsg };

        // Power -----------------------------
        let color = (this.jMsg.power ? "royalblue" : "slategray");

        $("#power_icon").css( 'color'      , color );
        $("#power_icon").css( 'borderColor', color );

        $("#div-tempe").prop('disabled', ! this.jMsg.power).find('*').prop('disabled', ! this.jMsg.power);
        $("#div-mode" ).prop('disabled', ! this.jMsg.power).find('*').prop('disabled', ! this.jMsg.power);
        $("#div-fan"  ).prop('disabled', ! this.jMsg.power).find('*').prop('disabled', ! this.jMsg.power);

        // Mode ------------------------------
        $('#modeCool').removeClass('is-info'   ).removeClass('is-light').removeClass('is-default');
        $('#modeHeat').removeClass('is-danger' ).removeClass('is-light').removeClass('is-default');
        $('#modeFan' ).removeClass('is-success').removeClass('is-light').removeClass('is-default');

        // Highlight the current mode button
        if( this.jMsg.mode == 'Cool' ) $("#modeCool").addClass('is-info'   ).addClass('is-light').addClass('is-default');;
        if( this.jMsg.mode == 'Heat' ) $("#modeHeat").addClass('is-danger' ).addClass('is-light').addClass('is-default');;
        if( this.jMsg.mode == 'Fan'  ) $("#modeFan" ).addClass('is-success').addClass('is-light').addClass('is-default');;

        if( jMsg.mode === 'Fan' )
        {
            $("#div-tempe").fadeTo( "slow", "0.15" );
            $("#div-tempe").prop( 'disabled', true );
        }
        else
        {
            $("#div-tempe").fadeTo( "slow", "1" );
            $("#div-tempe").prop( 'disabled', false );
        }

        // Fan -------------------------------
        $('[id^="fan_"]').css('color', 'gray');

        switch( this.jMsg.fan )
        {
         // case "Maximum": $('#fan_7').css('color', 'royalblue');    // Not use -> break;   --> Not currently used
            case "High"   : $('#fan_6').css('color', 'royalblue');    // Not use -> break;
            case "Medium" : $('#fan_5').css('color', 'royalblue');    // Not use -> break;
            case "Low"    : $('#fan_4').css('color', 'royalblue');    // Not use -> break;
            case "Minimum": $('#fan_3').css('color', 'royalblue');    // Not use -> break;
        }

        // Target Temperature  ---------------
        if( p_base.isNumber( this.jMsg.t_target ) )
        {
            if( this.jMsg.mode === 'Cool' || this.jMsg.mode === 'Heat' )
            {
                let min = this.oLimits[this.jMsg.mode].min;
                let max = this.oLimits[this.jMsg.mode].max;

                if( this.jMsg.t_target < min )
                    gum_ws.requestChange( oExEnAddr, 'clima_ctrl', { t_target: min } );

                if( this.jMsg.t_target > max )
                    gum_ws.requestChange( oExEnAddr, 'clima_ctrl', { t_target: max } );
            }

            $("#_target_tempe_").text( this.formatTemperature( this.jMsg.t_target ) );
        }
        else
        {
            let value = this.getShownTemperatureInCelsius();
                value = (value == null ? '--.-' : value);

            $("#_target_tempe_").text( value );
        }
    },

    //-------------------------------------------------------------------------------------------//
    // FUNCIONES AUXILIARES

    /**
     * Devuelve la q se está mostrando en el GUI.
     *
     * @returns {Number} La q se está mostrando en el GUI
     */
    getShownTemperatureInCelsius : function()
    {
        let guiValue = $("#_target_tempe_").text().trim();

        if( p_base.isNumber( guiValue ) )
            return null;

        guiValue = Number.parseFloat( guiValue );

        return (this.isFahrenheit() ? this.toCelsius( guiValue ) : guiValue);
    },

    /**
     * Añade un ".0" si lo necesita: "23" -> "23.0" y si hay más de un decimal,
     * los quita. El value pasado puede ser Celsius o Fahrenheit: funciona igual.
     *
     * @param {Number} value Temperatura a formatear
     */
    formatTemperature : function( value )
    {
        if( ! p_base.isNumber( value ) )
            return "??.?";

        if( this.isFahrenheit() )
            value = this.toFahrenheit( value );

        return parseFloat( value ).toFixed( 1 );
    },

    isFahrenheit : function()
    {
        return ($("#_tempe_unit_").text() === "F");
    },

    toFahrenheit : function( celsius )
    {
        return (celsius * 9 / 5) + 32;
    },

    toCelsius : function( fahrenheit )
    {
        return (fahrenheit - 32) * 5 / 9;
    }
};
}