"use strict";

if( typeof info === "undefined" )
{
var info =
{
    minWidth  : 1024,
    minHeight :  768,
    source    : "https://abubacocina.blogspot.com/",

    init : function()
    {
        let width  = parseInt( $('body').width()  -  20 );
        let height = parseInt( $('body').height() - 120 );

        width  = width  < info.minWidth  ? info.minWidth  : width;
        height = height < info.minHeight ? info.minHeight : height;

        $('#_info_').html('<iframe src="'+ info.source +'" width="'+ width +'" height="'+ height +'"></iframe>');
    }
}
};