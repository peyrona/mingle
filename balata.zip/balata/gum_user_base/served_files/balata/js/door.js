"use strict";

if( typeof door === "undefined" )
{
var door =
{
    bInited : false,

    init : function( aoDoors )
    {
        if( clima.bInited )
            return; //throw "Calling twice to clima:init()";

        this.bInited = true;

        let bRoomOK = false;

        for( const door of aoDoors )
            if( door.name === 'door_locker' )
                bRoomOK = true;

        if( ! bRoomOK )
            throw "Internal error: 'door_locker' device not found"
    },

    openRoom : function()
    {
        door._setRoomDoor_( true );

        setTimeout( () => door._setRoomDoor_( false ), 3*1000 );
    },

    openStreet : function()
    {
        p_app.alert('No hecho aún');
    },

    //------------------------------------------------------------------------//

    _setRoomDoor_ : function( bOpen )
    {
        gum_ws.requestChange( oExEnAddr, 'door_locker', bOpen );
    }
};
}