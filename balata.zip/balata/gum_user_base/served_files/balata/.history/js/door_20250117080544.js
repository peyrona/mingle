"use strict";

if( typeof door === "undefined" )
{
var door =
{
    init : function()
    {
    },

    openRoom : function()
    {
        gum_ws.requestChange( oExEnAddr, 'door_locker', true );

        setTimeout( function(){ gum_ws.requestChange( oExEnAddr, 'door_locker', false ) }, 3*1000 );
    },

    openStreet : function()
    {
        p_app.alert('No hecho aún');
    }
};
}