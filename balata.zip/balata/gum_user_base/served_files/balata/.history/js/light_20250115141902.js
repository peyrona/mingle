
"use strict";

if( typeof light === "undefined" )
{
var light =
{
    sRowTemplate :  '<tr>'+
                    '    <td align="left" style="width:20%; text-align:left; vertical-align:middle; font-size:3vw;">'+
                    '        _label_'+
                    '    </td>'+
                    '    <td align="center" style="width:50%; vertical-align: middle;">'+
                    '        <input id="dimm_name_"'+
                    '               type="range"'+
                    '               min="0" max="100" step="1"'+
                    '               value="0"'+
                    '               oninput="light.onDimmed( \'_name_\', \'input\' )"'+
                    '               onchange="light.onDimmed( \'_name_\', \'change\' )"'+
                    '               style="width:100%; visibility:_show_dimm_"/>'+
                    '    </td>'+
                    '    <td align="center" style="width:15%; vertical-align:middle;">'+
                    '        <div style="visibility:_show_color_"><input type="text" id="rgb_name_"></div>'+
                    '    </td>'+
                    '    <td align="right" style="width:15%; style="vertical-align:middle;">'+
                    '        <img id="onoff_name_" src="" alt="light on off" onclick="light.onOnOff( \'_name_\' )"'+
                    '             style="cursor:pointer; width:auto; height:4vw; min-width:32px; min-height:36px;'+
                    '                    padding-top:4px; padding-bottom:3px; border:1px solid #888888; border-radius:4px">'+
                    '    </td>'+
                    '</tr>',

    asPalette : [ ['white', 'red', 'green', 'blue'],
                  ['violet', 'brown', 'pink', 'yellow'] ],

    aoLights  : [],   // {name:<str>, dimm:<boolean>, rgb:<boolean>}   // All RGB are dimmable but the opposite is not always true

    init : function( aoLights )
    {
        this.aoLights = [];

        for( const oLight of aoLights )
        {
            let sGroups = ((oLight.init && oLight.init.hasOwnProperty('groups')) ? oLight.init.groups.toLowerCase() : "");

            this.aoLights.push( { name: oLight.name,                // Full name is needed to later switch it on and off
                                  dimm: sGroups.includes( "dimm" ),
                                  rgb : sGroups.includes( "rgb"  ) } );
        }

        this.aoLights.sort( (a,b) => a.name.localeCompare(b.name) );
        this.fillTable();

        for( const oLight of aoLights )
            gum_ws.requestValue( oLight.name );
    },

    // A message has arrived from Domotics's Server informing a device has changed its status.
    update : function( name, value )    //  $(p_base.get("color-"+result[n].id )).spectrum( { showPalette: true, palette: this.pal, change: function(clr) { onColorChanged( this ); } } );
    {
        if( p_base.isBoolean( value ) )
        {
            $('#onoff'+name).attr('src', 'images/light_'+ (value ? 'on' : 'off') +'.png');
        }

        // Others can also be dimmed (a light that can be dimmed is assumed it is also RGB)
        // let cande = p_base.get( "candela-" + jMsg.id );
        // let color = p_base.get( "color-"   + jMsg.id );
        // let codec = new LuminaCodec( parseInt( jMsg.value, 10 ) );    // base === 10
        // isLightOn   = codec.getCandela() > 0;
        // cande.value = codec.getCandela();
        // $(color).spectrum( "set", codec.getHex() );

        // $(elementOnOff).attr( "src", "images/light_"+ (isLightOn ? "on" : "off") +".png" );

        this.refreshButtonAllOff();
    },

    // El usuario ha pulsado el icono de encender/apagar una luz.
    onOnOff : function( name )
    {
        let bStateNow = this.isLightOn( name );

        gum_ws.requestChange( oExEnAddr, name, ! bStateNow );
    },

    // El usuario ha pulsado el botón de apagar todas las luces.
    onAllOff : function()
    {
        for( const oLight of this.aoLights )
        {
            gum_ws.requestChange( oExEnAddr, oLight.name, false );
        }

        p_base.get( "btnAllOff" ).disabled = true;
    },

    // Tells server that user has changed the slider.
    onDimmed : function( lightId, methodName )
    {
        // I do not test if light is on, because by moving the slider the light will be set to on and to the specific percentage.

        if( processRangeEvent( methodName, false ) )   // false because the hardware I'm using is too slow
        {
            // Se ha cambiado la candela: hay q igualar los valores de R, G y B (así es como lo hacen los programas profesionales)
            let candela = p_base.get( "candela-"+ lightId).value;
            let rgb     = Number.parseInt( candela * 255 / 100 );     // Paso de 0% a 100% --> 0 a 255
            let codec   = new LuminaCodec( candela, rgb, rgb, rgb );

            ///////////////////////////////////////////////new RPC().to( lightId ).action( "set" ).set( codec.getEncoded() );
        }
    },

    // User changed desired color
    onColorChanged : function( elemColor )
    {
// https://coloris.js.org/
// https://iro.js.org/introduction.html
        let id = elemColor.id;
            id = id.substring( "color-".length );

        let candela = p_base.get( "candela-"+ id );     // Mando la candela, aunque el server no debería necesitarla
        let rgb     = $(p_base.get( "color-"+ id )).spectrum( "get" ).toRgb();
        let codec   = new LuminaCodec( candela.value, rgb.r, rgb.g, rgb.b );

        //////////////////////////////////////////new RPC().to( id ).action( "set" ).set( codec.getEncoded() );
    },

    // Activa o desactiva el botón de apagar todas las luces.
    refreshButtonAllOff : function()
    {
        let bDisabled = true;

        for( const oLight of this.aoLights )
        {
            if( this.isLightOn( oLight.name ) )
            {
                bDisabled = false;
                break;
            }
        }

        p_base.get( "btnAllOff" ).disabled = bDisabled;
    },

    fillTable : function()
    {
        $('#tbl_light').empty();

        for( const oLight of this.aoLights )
        {
            let sRow = this.sRowTemplate.replace( /_label_/g     , oLight.name.substr( 6 ) )              // All Balata light device names start with 'light_'
                                        .replace( /_name_/g      , oLight.name )
                                        .replace( /_show_dimm_/g , (oLight.dimm ? "visible" : "hidden") )
                                        .replace( /_show_color_/g, (oLight.rgb  ? "visible" : "hidden") )
                                        .replace( /src=""/g      , 'src="images/light_off.png"' );

            $('#tbl_light').append( sRow );

            gum_ws.requestValue( oExEnAddr, oLight.name );
        }
    },

    //------------------------------------------------------------------------//
    // AUXILIARY  METHODS

    isLightOn : function( lightName )
    {
        let elementOnOff = p_base.get( "onoff"+ lightName );

        if( $(elementOnOff).is( "img" ) )
        {
            return $(elementOnOff).attr( 'src' ).toLowerCase().indexOf( "light_on" ) > -1;
        }

        alert( "Error: passed elment is not an image" );
    },

    /**
     * Devuelve true si el evento asocaido al 'input' de tipo 'range' debe ser
     * procesado en las condiciones dadas.
     * <p>
     * El problema es q (como de costumbre) los distintos navegadores procesan de
     * modo diferente los eventos de "range" (slider). En algunas ocasiones se
     * desea procesar todos los eventos q se producen cuendo el usuario arrastra
     * el botoncito del slider y otras veces sólo interesa el valor cuando lo ha
     * soltado. De esto se encarga esta función.
     *
     * @param {String} sEventName 'input' o 'change'
     * @param {Boolean} bReportIntermediate true para procesar todos los eventos.
     * @returns {Boolean} true si el evento debe ser procesado en las condiciones dadas.
     */
    processRangeEvent : function( sEventName, bReportIntermediate )
    {
        if( bReportIntermediate )    // Se quiere informar de valores intermedios
        {
            return (sEventName === 'input') || isIE();
        }

        return (sEventName === 'change');
    }
};
}