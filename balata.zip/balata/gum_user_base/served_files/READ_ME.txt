The files shown here are served by Gum from context 'user_files'.
For full URL, refer to Gum (an HTTP Server) startup console info.