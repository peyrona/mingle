//------------------------------------------------------------------------//
// NEXT: Esta pág sólo maneja un ctrl de clima (habría q mejorarla para más de uno)

"use strict";

if( typeof clima === "undefined" )
{
var clima =
{
    jMsg      : {},    // Last received JSON message about the state of the Emura
    bInited   : false,
    aContacts : [],    // Windows contact (open/close)
    oLimits   : { 'Cool': { min:19, max:29 } , 'Heat': { min:17, max:24 } },   // jMsg.Mode: 'Cool', 'Heat', 'Dry' or 'Auto'

    init : function()
    {
        if( ! clima.bInited )
        {
            clima.bInited = true;

            gum_ws.addListener( oExEnAddr, ['contact_chorron', 'contact_solano', 'contact_bath'],
                                (when, devName, devValue) => clima.onWindoStateChanged( devName, devValue ) );

            gum_ws.addListener( oExEnAddr, 'clima_sensor',
                                (when, devName, devValue) =>
                                {
                                    $('#temperature_inside' ).text( clima.formatTemperature( devValue.data.t_inside  ) + (clima.isFahrenheit() ? 'F' : 'C') );
                                    $('#temperature_outside').text( clima.formatTemperature( devValue.data.t_outside ) + (clima.isFahrenheit() ? 'F' : 'C') );
                                } );

            gum_ws.addListener( oExEnAddr, 'clima_ctrl',
                                (when, devName, devValue) => clima.updateUI( devValue.data ) );
        }

        setTimeout( () => {
                            gum_ws.requestValue( oExEnAddr, 'clima_sensor' );
                            gum_ws.requestValue( oExEnAddr, 'clima_ctrl'   );
                          },
                    900 );   // Time to paint the UI
    },

    // A message has arrived from the Server informing a device has changed its status.
    updateUI : function( jMsg )
    {
        this.jMsg = { ...this.jMsg, ...jMsg };   // jMsg could arrive with all values or only one; v.g.: { power: true }

        // Power -----------------------------
        let color = (this.jMsg.power ? "royalblue" : "slategray");
        let opaco = (this.jMsg.power ? "1" : "0.15");

        $("#power_icon").css( 'color'      , color );
        $("#power_icon").css( 'borderColor', color );

        $("#div-tempe").fadeTo( "slow", opaco );
        $("#div-mode" ).fadeTo( "slow", opaco );
        $("#div-fan"  ).fadeTo( "slow", opaco );

        // Mode ------------------------------
        $("[id^=mode]")          // Todos los id q empiezan por 'mode_',
            .each( function()    // los pongo como 'btn-default'
                   {
                       $(this).removeClass('is-danger').removeClass('is-light').addClass('is-default');
                   } );

        $("#mode"+ this.jMsg.mode).addClass('is-danger').addClass('is-light');   // Pongo activo el q corresponde

        if( jMsg.mode === 'Fan' )
        {
            $("#div-tempe").fadeTo( "slow", "0.15" );
            $("#div-tempe").prop( 'disabled', true);
        }

        // Fan -------------------------------
        $('[id^="fan_"]').css('color', 'gray');

        switch( this.jMsg.fan )
        {
            case "Maximum": $('#fan_7').css('color', 'royalblue');    // Not use -> break;
            case "High"   : $('#fan_6').css('color', 'royalblue');    // Not use -> break;
            case "Medium" : $('#fan_5').css('color', 'royalblue');    // Not use -> break;
            case "Low"    : $('#fan_4').css('color', 'royalblue');    // Not use -> break;
            case "Minimum": $('#fan_3').css('color', 'royalblue');    // Not use -> break;
        }

        // Target Temperature  ---------------
        if( (this.jMsg.mode === 'Cool' || this.jMsg.mode === 'Heat') &&  p_base.isNumber( this.jMsg.t_target ) )
        {
            if( this.jMsg.t_target > this.oLimits[this.jMsg.mode].max )
                gum_ws.requestChange( oExEnAddr, 'clima_ctrl', { t_target: this.oLimits[jMsg.mode].max } );

            if( this.jMsg.t_target < this.oLimits[this.jMsg.mode].min )
                gum_ws.requestChange( oExEnAddr, 'clima_ctrl', { t_target: this.oLimits[jMsg.mode].min } );

            let temperature = (this.isFahrenheit() ? this.toFahrenheit( this.jMsg.t_target ) : this.jMsg.t_target);

            $("#_target_tempe_").text( this.formatTemperature( temperature ) );
        }
        else if( this.getShownTemperatureInCelsius() == null )
        {
            $("#_target_tempe_").text('???');
        }
    },

    onPowerClicked : function()
    {
        if( this.aContacts.length > 0 )
            return;

        if( this.jMsg.power )
        {
            gum_ws.requestChange( oExEnAddr, 'clima_ctrl', { power: false } );
            blockGUI( (isDevEnv ? 1 : 20) );
        }
        else    // Está en OFF
        {
            gum_ws.requestChange( oExEnAddr, 'clima_ctrl', { power: true } );
            blockGUI( (isDevEnv ? 1 : 17) );
        }
    },

    onModeClicked : function( source )
    {
        if( ! this.jMsg.power )
            return;

        let mode = null;

        switch( source.id )
        {
            case 'modeAuto': mode = 'Auto'; break;
            case 'modeCool': mode = 'Cool'; break;
            case 'modeDry' : mode = 'Dry';  break;
            case 'modeHeat': mode = 'Heat'; break;
            case 'modeFan' : mode = 'Fan';  break;
            default        : throw 'Error';
        }

        if( this.jMsg.mode !== mode )
        {
            gum_ws.requestChange( oExEnAddr, 'clima_ctrl', { mode: mode } );
            blockGUI( 1 );
        }
    },

    onFanclicked : function( source )
    {
        if( ! this.jMsg.power )
            return;

        let level = null;

        switch( source.id )
        {
            case 'fan_7': level = 'Maximum'; break;
            case 'fan_6': level = 'High';    break;
            case 'fan_5': level = 'Medium';  break;
            case 'fan_4': level = 'Low';     break;
            case 'fan_3': level = 'Minimum'; break;
            default     : throw 'Error';
        }

        if( this.jMsg.fan !== level )
        {
            gum_ws.requestChange( oExEnAddr, 'clima_ctrl', { fan: level } );
            blockGUI( 1 );
        }
    },

    onIncrTempe : function( incr )       // incr puede ser positivo (.5) o negativo (-.5)
    {
        if( ! this.jMsg.power )
            return;

        if( (this.jMsg.mode !== 'Cool') && (this.jMsg.mode !== 'Heat') )
            return;
                                                                // 21ºC is the default
        let value = (this.getShownTemperatureInCelsius() == null ? 21 : this.getShownTemperatureInCelsius()) + incr;
        let min   = this.oLimits[this.jMsg.mode].min;
        let max   = this.oLimits[this.jMsg.mode].max;

        value = value < min ? min : value;
        value = value > max ? max : value;

        gum_ws.requestChange( oExEnAddr, 'clima_ctrl', { t_target: value } );

        blockGUI( .5 );
    },

    /**
     * Se han abierto o cerrado ventanas en la habitación.
     */
    onWindoStateChanged : function( sDevName, isClosed )
    {
        if( isClosed )     // Window had been closed
        {
            if( this.aContacts.includes( sDevName ) )
                this.aContacts.splice( this.aContacts.indexOf( sDevName ), 1 );   // Removes from array
        }
        else
        {
            if( ! this.aContacts.includes( sDevName ) )
                this.aContacts.push( sDevName );                                  // Adds to array
        }

        if( this.aContacts.length > 0 )  $("#_info_box_").show();
        else                             $("#_info_box_").hide();

        if( this.aContacts.length > 0 && this.jMsg.power )
            gum_ws.requestChange( oExEnAddr, 'clima_ctrl', { power: false } );
    },

    onChangeUnit : function()
    {
        let value = $("#_target_tempe_").text();

        if( p_base.isEmpty( value ) )    // Si está vacía la temperatura de consigna
            return;

        value = Number.parseFloat( value );

        if( ! Number.isNaN( value ) )
        {
            if( this.isFahrenheit() )   // Pasamos a Celsius
            {
                value = this.toCelsius( value );
                $("#_tempe_unit_").html( "C" );
            }
            else                        // Pasamos a Fahrenheit
            {
                value = this.toFahrenheit( value );
                $("#_tempe_unit_").html( "F" );
            }

            $("#_target_tempe_").text( this.formatTemperature( value ) );
        }
    },

    onHelp : function()
    {
        $("#ClimaHelpDialog").dialog();
    },

    //************************************************************************//
    // FUNCIONES AUXILIARES

    /**
     * Devuelve la q se muestra en el GUI.
     *
     * @returns {Number} La q se muestra en el GUI
     */
    getShownTemperatureInCelsius : function()
    {
        var guiValue = $("#_target_tempe_").text().trim();

        if( p_base.isNumber( guiValue ) )
        {
            return null;
        }

        guiValue = Number.parseFloat( guiValue );

        return (this.isFahrenheit() ? this.toCelsius( guiValue ) : guiValue);
    },

    /**
     * Añade un ".0" si lo necesita: "23" -> "23.0" y si hay más de un decimal,
     * los quita. El value pasado puede ser Celsius o Fahrenheit: funciona igual.
     *
     * @param {Number} value Temperatura a formatear
     */
    formatTemperature : function( value )
    {
        if( ! p_base.isNumber( value ) )
            return "??.?";

        value = value.toString().trim();

        if( value.length > 4 )
        {
            value = value.substring( 0, 4 );
        }

        let ndx = value.indexOf( "." );

             if( ndx === -1 )                               value += '.00';
        else if( value.substring( ndx + 1 ).length === 1 )  value += '0';

        return value;
    },

    isFahrenheit : function()
    {
        return ($("#_tempe_unit_").text() === "F");
    },

    toFahrenheit : function( celsius )
    {
        return (celsius * 9 / 5) + 32;
    },

    toCelsius : function( fahrenheit )
    {
        return (fahrenheit - 32) * 5 / 9;
    }
};
}