"use strict";

if( typeof door === "undefined" )
{
var door =
{
    init : function()
    {
        /*const imgDoor = document.getElementById( "btn-door" );

            $.ajax( {
                        type    : "GET",
                        url     : "/"+ getContextPath() +"/ws/rt/control",
                        dataType: "json",
                        data    : { zone: getZoneName(), name: "btn-open-door" },
                        error   : function( error  ) { showAjaxError( error ); },
                        success : function( result )
                                    {
                                        imgDoor.id  = result.id;
                                        imgDoor.alt = result.caption;
                                    }
                    } );*/
    },

    openRoom : function()
    {
        gum_ws.requestChange( oExEnAddr, 'relay_door', true );

        setTimeout( function(){ gum_ws.requestChange( oExEnAddr, 'relay_door', false ) }, 3*1000 );
    },

    openStreet : function()
    {
        p_app.alert('No hecho aún');
    }
};
}