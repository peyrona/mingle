"use strict";

if( typeof alarm === "undefined" )
{
var alarm =
{
    state : { e1: false, a1: false, e2: false, a2: false },

    init : function()
    {
        /*
            let imgSurv = document.getElementById( "btn-surveillance" );
                imgSurv.addEventListener( "touchstart", function( evt ) { onSurveillance( evt ); }, false );
                imgSurv.addEventListener( "click"     , function( evt ) { onSurveillance( evt ); }, false );

            $.ajax(
                {
                type    : "GET",
                url     : "/"+ getContextPath() +"/ws/rt/control",
                dataType: "json",
                data    : { "type": "vigilancia" },
                error   : function( error  ) { showAjaxError( error ); },
                success : function( result )
                            {
                                $('#surveillance-label').text( result.caption );
                                $('[name="surveillance-image"]').prop( "id" , result.id );
                                $('[name="surveillance-image"]').prop( "alt", result.caption );
                                new RPC().to( result.id ).get();
                            }
                } );*/
    },

    /**
     * Changes the alarm state for one zone or all zones.
     *
     * @param {String} sWhich By default null: set all zones to opposite to current.
     * @param {Boolean} bNewState By default the opposite to current.
     */
    set : function( sWhich = null, bNewState )
    {
        if( sWhich )
            sWhich = sWhich.toLowerCase();

        if( sWhich && (! bNewState) )
            bNewState = ! this.state[sWhich];

        switch( sWhich )
        {
            case "e1" || null: break;
            case "a1" || null: break;
            case "e2" || null: break;
            case "a2" || null: break;
        }
    }
};
}