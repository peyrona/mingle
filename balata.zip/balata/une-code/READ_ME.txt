
These are the Une scripts that I use to control my own little hotel.

My hotel has:
   * 1 hall
   * 4 apartments
   * 2 terraces
   * 1 machinery room
   * 1 keypad to open the street door


Every apartment has:
   * 1 keypad to open the door
   * 1 kitchen or kitchenet
   * 1 bathroom
   * 1 Daikin Emura A.C.
   * Lights: On/Off, dimmed and RGB
   * Push-buttons to manage lights
   * Its own WiFi subnet
