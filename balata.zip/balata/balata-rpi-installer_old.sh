#!/bin/bash

clear

# Was the script executed as 'sudo'?
if [ "$EUID" -ne 0 ]; then
    echo ">>> ERROR <<<"
    echo "This script must be executed as root: 'sudo balata-rpi-installer.sh'"
    exit 1
fi

# Is this a Raspberry Pi?
what_am_i=$(uname -m)
if [[ $what_am_i != *"arm"* ]]; then
    echo ">>> ERROR <<<"
    echo "Este script solo puede ejecutarse en una arquitectura ARM."
    echo "Y esta no parece serlo."
    exit 1
fi

# Define work path
work_path="/home/pi/balata"

# Menu ------------------
echo "-------------------------------------------------------------------"
echo " This script configures a Raspbian OS to be used at Balata house"
echo "-------------------------------------------------------------------"
echo "  "
read -r -p "Proceder? [s/N] " response
response=${response,,}    # tolower
if [[ ! $response =~ ^(si|sí|s|yes|y)$ ]]; then
    exit 0
fi

# -----------------------------------------------------------------------
# Setting a fixed IP

# Get the local IP address using ifconfig
local_ip=$(hostname -I | awk '{print $1}')

# Array of allowed IP addresses with their descriptions
declare -A ip_config=(
    ["6"]="E1:192.168.1.6"
    ["7"]="A1:192.168.1.7"
    ["8"]="E2:192.168.1.8"
    ["9"]="A2:192.168.1.9"
)

# Check if current IP matches any allowed IP
current_ip_valid=false
for config in "${ip_config[@]}"; do
    if [ "$local_ip" == "${config#*:}" ]; then
        current_ip_valid=true
        break
    fi
done

if [ "$current_ip_valid" != true ]; then
    echo "Escoje el numero asociado a la maquina que se esta configurando:"
    for key in "${!ip_config[@]}"; do
        echo "$key -> ${ip_config[$key]%%:*}"
    done

    while true; do
        read -p "? " ip_choice
        if [[ -n "${ip_config[$ip_choice]}" ]]; then
            break
        fi
        echo "Opción inválida. Por favor, seleccione un número válido."
    done

    fixed_ip="${ip_config[$ip_choice]#*:}"
    router_ip="192.168.1.1"
    dns_ip="1.1.1.1 9.9.9.9"

    # Backup original config
    cp /etc/dhcpcd.conf /etc/dhcpcd.conf.backup

    # Add static IP configuration
    cat << EOF >> /etc/dhcpcd.conf

# ----------------------------------
# IP estatica customizada para eth0.
# ----------------------------------
interface eth0
static ip_address=$fixed_ip/24
static routers=$router_ip
static domain_name_servers=$dns_ip
EOF

    systemctl restart dhcpcd

    echo "Se ha establecido la IP  : $fixed_ip"
    echo "El router tiene la IP    : $router_ip"
    echo "El DNS Server tiene la IP: $dns_ip"
fi

# System upgrade
echo "-----------------------------------------------------------"
echo "Linux will be upgraded (Internet connection is needed)"
read -r -p "Proceder? [s/N] " response
response=${response,,}
if [[ $response =~ ^(si|sí|s|yes|y)$ ]]; then
    apt-get update
    apt-get install -y htop
    apt-get upgrade -y
    echo "Hecho."
fi

# Language configuration
echo "-----------------------------------------------------------"
echo "OS LANGUAGE will be configured (Internet connection is needed)"
read -r -p "Proceder? [s/N] " response
response=${response,,}
if [[ $response =~ ^(si|sí|s|yes|y)$ ]]; then
    # Check if locales already exist
    if ! locale -a | grep -q "en_US.utf8"; then
        locale-gen "en_US.UTF-8"
    fi
    if ! locale -a | grep -q "es_ES.utf8"; then
        locale-gen "es_ES.UTF-8"
    fi
    dpkg-reconfigure locales
    echo "Hecho."
fi

# -----------------------------------------------------------------------
# Change TimeZone to 'Madrid' and uses 'pool.ntp.org' as NTP server
if ! timedatectl | grep -q "Europe/Madrid"; then
    timedatectl set-ntp true
    timedatectl set-timezone Europe/Madrid
    if ! grep -q "^NTP=pool.ntp.org" /etc/systemd/timesyncd.conf; then
        sed -i '/\[Time\]/a NTP=pool.ntp.org' /etc/systemd/timesyncd.conf
    fi
    systemctl restart systemd-timesyncd
    echo "Hecho."
fi

# -----------------------------------------------------------------------
# Configure Watchdog
echo "-----------------------------------------------------------"
echo "Configuring hardware watchdog..."
if ! dpkg -l | grep -q '^ii  watchdog'; then
    apt-get update
    apt-get install -y watchdog

    # Enable and configure watchdog kernel module
    if ! grep -q "^bcm2708_wdog" /etc/modules; then
        echo "bcm2708_wdog" >> /etc/modules
    fi
    modprobe bcm2708_wdog

    # Configure watchdog
    cat << EOF > /etc/watchdog.conf
watchdog-device = /dev/watchdog
watchdog-timeout = 30
max-load-1 = 36
min-memory = 5
EOF

    # Enable watchdog service
    systemctl enable watchdog
    systemctl start watchdog

    # Verify watchdog is running
    if lsmod | grep -q "bcm2708_wdog" && systemctl is-active --quiet watchdog; then
        echo "Watchdog installed and configured successfully."
    else
        echo "Warning: Watchdog installation may have failed. Please check manually."
    fi
fi

# -----------------------------------------------------------------------
# Change user's 'pi' password
echo "-----------------------------------------------------------"
echo "Changing password for user 'pi'..."
echo "pi:balata0801" | chpasswd
echo "The new password for user 'pi' is: 'balata0801'"

# -----------------------------------------------------------------------
# Change ownership of work directory
echo "-----------------------------------------------------------"
echo "Se va a cambiar el owner de 'root' a 'pi' en la carpeta '$work_path' y subcarpetas"
read -r -p "Proceder? [s/N] " response
response=${response,,}
if [[ $response =~ ^(si|sí|s|yes|y)$ ]]; then
    mkdir -p "$work_path"
    chown -R pi:pi "$work_path"
    echo "Hecho"
fi

echo "-----------------------------------------------------------"
echo "Configuración process is finished."
echo "The next step is to install Mingle Platform."
read -r -p "Reiniciar el sistema? [s/N] " response
response=${response,,}
if [[ $response =~ ^(si|sí|s|yes|y)$ ]]; then
    shutdown -r now
fi